package app.springbootdemo.database.dbmodel;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@Entity
@Table(name = "WORKING_CALENDAR")
public class TimeTable implements Serializable {


    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(name = "Start_Time")
    @JsonDeserialize(using=CustomerDateAndTimeDeserialize.class)
    private Date begin;

    @Column(name = "end_Time")
    @JsonDeserialize(using=CustomerDateAndTimeDeserialize.class)
    private Date end;

    @Column(name = "begin_break")
    @JsonDeserialize(using=CustomerDateAndTimeDeserialize.class)
    private Date begin_break;

    @Column(name = "end_break")
    @JsonDeserialize(using=CustomerDateAndTimeDeserialize.class)
    private Date end_break;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getBegin() {
        return begin;
    }

    public void setBegin(Date begin) {
        this.begin = begin;
    }

    public Date getEnd() {
        return end;
    }

    public void setEnd(Date end) {
        this.end = end;
    }

    public Date getBegin_break() {
        return begin_break;
    }

    public void setBegin_break(Date begin_break) {
        this.begin_break = begin_break;
    }

    public Date getEnd_break() {
        return end_break;
    }

    public void setEnd_break(Date end_break) {
        this.end_break = end_break;
    }


}
