package app.springbootdemo.controller.model;

import java.util.HashSet;
import java.util.Set;

public class IllView {



    private String empId;

    private String illDate;

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }


    public String getIllDate() {
        return illDate;
    }

    public void setIllDate(String illDate) {
        this.illDate = illDate;
    }
}
