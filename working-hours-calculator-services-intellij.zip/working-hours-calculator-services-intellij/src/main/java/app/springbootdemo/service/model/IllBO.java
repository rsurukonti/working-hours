package app.springbootdemo.service.model;

public class IllBO {


    private String empId;

    private String illDate;


    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getIllDate() {
        return illDate;
    }

    public void setIllDate(String illDate) {
        this.illDate = illDate;
    }
}
